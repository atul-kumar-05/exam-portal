package com.exam.portal.entities.jsonclasses;

public class TagDetectionResponse {
    private JsonObject result;

    public JsonObject getResult() {
        return result;
    }

    public void setResult(JsonObject result) {
        this.result = result;
    }
}

