# Exam-Portal
It is a Java based application which facilitate teachers to organize online exams among students <br> And help teeacher in management of exam records.<br>

# Features :
# Basic -
1. Different login portal for teacher and student.<br>
2. Teacher has option to create new teams and add students in the team. <br>
3. Teacher can create exams in teams and add multiple choice question in question paper . <br>
4. Student has option to join any team using team id. <br>
5. Teacher and Student both can see all Scheduled exam. <br>
6. Teacher can view submission all the students after exam finished and can update marks. <br>
7. Student can view his submission after exam finished with correct answere of all question. <br>
8. Exams are proctored and application continuously captures student's image and check it for face count and check it's tags. <br>
9. Application continuously count the number of application running if student open any other application then he/she will be logged out from exam <br>

# Advanced
1. Question paper may contain question of type like MCQ , Subjective or Images.<br>
2. There may be multiple exams running in application at same time.<br>
3. Application provides chat functionality in each team where student can clarify their doubts regarding exams.<br>

# Screenshots -
![Screenshot (160)](https://user-images.githubusercontent.com/68137797/147472537-f9dd753c-3e67-41d9-a27d-5b59322a76d9.png)
![Screenshot (161)](https://user-images.githubusercontent.com/68137797/147472552-253452db-e448-49a6-b08a-64268ae4dd62.png)
![Screenshot (162)](https://user-images.githubusercontent.com/68137797/147472567-6ef2089e-bb90-4124-b0c9-a0968c88314f.png)
![Screenshot (164)](https://user-images.githubusercontent.com/68137797/147472581-70c93b9a-ffec-40c2-8031-fbe8a6e07bea.png)
![Screenshot (165)](https://user-images.githubusercontent.com/68137797/147472687-6903e73e-c982-4807-82e6-dafbb28d8fa7.png)
![Screenshot (166)](https://user-images.githubusercontent.com/68137797/147472723-f2903716-e892-4cc5-bd77-85b41c9025c8.png)
